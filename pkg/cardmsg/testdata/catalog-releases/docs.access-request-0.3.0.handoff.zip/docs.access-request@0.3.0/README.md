# 文档访问申请 backend handoff

- Card: `docs.access-request@0.3.0`
- Contract: `1.1.0`
- Adaptive Card: `1.5`
- Render Profile: `octo-chat@1.2.0-rc.4`

Use `contract/data.schema.json` to map backend data. Use `render-profile/capabilities.json` for Server-side final validation. Octo Web must load the matching Render Profile package resources together; do not mix CSS/theme/tokens from another version. The `goldens/` directory contains expected compiled Card JSON for each sample. The `reports/` directory documents standard Action/Input/Toggle behavior.
